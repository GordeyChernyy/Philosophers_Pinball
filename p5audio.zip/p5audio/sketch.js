//=========================================================
// SOUND DESIGN CHALLENGE - MAKE BETTER SOUNDS AND FIND
// THE RIGHT VOLUME LEVELS FOR THEM
// ALL YOUR MODIFIABLE VARIABLES ARE IN THIS SECTION!
// DO NOT MODIFY ANYTHING IN THE GAME'S CODE
//=========================================================
//Bennett Foddy - NYU Game Center 2015-2017

var start_game = 'assets/blip.wav'; //players at the start of a game.
var start_game_volume = 1.0;

var end_game = 'assets/blip.wav'; //on game over
var end_game_volume = 1.0;

var serve = 'assets/blip.wav'; //at the start of a point
var serve_volume = 1.0;

var player_one_scored = 'assets/silence.wav'; //when the player scores a point
var player_one_scored_volume = 1.0;

var player_two_scored = 'assets/silence.wav'; 
var player_two_scored_volume = 1.0;

var player_one_hit = 'assets/blip.wav'; //when the player hits the ball
var player_one_hit_volume = 1.0;

var player_two_hit = 'assets/blip.wav';
var player_two_hit_volume = 1.0;

var wall_bounce = 'assets/blip.wav'; //when the ball hits a wall
var wall_bounce_volume = 1.0;

//these three sounds are all looping sounds

var spinning_ball_loop = 'assets/spinloop.wav'; //this one is always playing, but it plays louder if the ball is spinning fast
var spinning_ball_loop_volume = 1.0;

var player_one_move_loop = 'assets/noise.wav'; //noise for when player is moving
var player_one_move_loop_volume = 1.0;

var player_two_move_loop = 'assets/noise.wav';
var player_two_move_loop_volume = 1.0;

//=========================================================
// MODIFY NOTHING BELOW THIS POINT
//=========================================================





// I MEAN IT





//variables to hold the sounds
var startSound;
var endSound;
var serveSound;
var p1ScoreSound;
var p2ScoreSound;
var p1HitSound;
var p2HitSound;
var wallSound;
var spinSound;
var p1moveSound;
var p2moveSound;


//nice pixel font
var pixelFont;

var batImg;
var ballImg;
var ball;
var p1;
var p2;
var topWall;
var walls;
var endZones;
var middleLine;

var p1Score;
var p2Score;

var player_accel = 0.3;
var player_damping = 0.5;
var serveSpeed = 3;
var serveTimer;
var serveTime = 2.0;



//here we are going to load all the files and store them in the variables
//it's advisable to do this in the preload() function, which runs before the game starts
function preload() {
	startSound = loadSound(start_game);
	endSound = loadSound(end_game);
	serveSound= loadSound(serve);
	p1ScoreSound= loadSound(player_one_scored);
	p2ScoreSound= loadSound(player_two_scored);
	p1HitSound= loadSound(player_one_hit);
	p2HitSound= loadSound(player_two_hit);
	wallSound= loadSound(wall_bounce);
	spinSound= loadSound(spinning_ball_loop);
	p1moveSound= loadSound(player_one_move_loop);
	p2moveSound= loadSound(player_two_move_loop);

	batImg = loadImage("assets/whiterect.png");
	ballImg = loadImage("assets/whitesquare.png");
	pixelFont = loadFont("assets/kroeger.ttf");
}

//the setup() function runs once, after all the files are loaded in preload()
//generally this is used to set up the game world and all the objects
function setup() {
	startSound.setVolume(start_game_volume);
	endSound.setVolume(end_game_volume);

	serveSound.setVolume(serve_volume);
	p1ScoreSound.setVolume(player_one_scored_volume);

	p2ScoreSound.setVolume(player_two_scored_volume);

	wallSound.setVolume(wall_bounce_volume);
	p1HitSound.setVolume(player_one_hit_volume);
	p2HitSound.setVolume(player_two_hit_volume);

	spinSound.loop();
	p1moveSound.loop();
	p2moveSound.loop();
	spinSound.setVolume(0);
	p1moveSound.setVolume(0);
	p2moveSound.setVolume(0);

	// create the canvas with the specficed size.
	var canvas = createCanvas(640,400); 
	canvas.parent("container"); //position the canvas within the html, look in the index.html file for the div called "container"

	//set the font and fontsize
	textFont(pixelFont);
	textSize(40);	
	textAlign(CENTER);
	resetGame();
}

function resetGame(){

	//need to make these walls pretty thick so that we don't miss any collisions!
	walls = new Group();
	var topWall = createSprite(width/2,0);
	topWall.setCollider("rectangle", 0,-49,width,100)
	topWall.debug = true;
	walls.add(topWall);

	var bottomWall = createSprite(width/2,height);
	bottomWall.setCollider("rectangle", 0,49,width,100)
	bottomWall.debug = true;
	walls.add(bottomWall);

	endZones = new Group();
	var leftZone = createSprite(0,height/2);
	leftZone.setCollider("rectangle", -49,0,100,height*1.5);
	leftZone.playerNum = 2; //this is the player that should score if this zone is hit
	leftZone.debug = true;
	endZones.add(leftZone);

	var rightZone = createSprite(width,height/2);
	rightZone.setCollider("rectangle", 49,0,100,height*1.5);
	rightZone.playerNum = 1; //this is the player that should score if this zone is hit
	rightZone.debug = true;
	endZones.add(rightZone);

	middleLine = createSprite(width/2,height/2);
	middleLine.setCollider("rectangle",0,0,10,height);
	middleLine.debug =true;

	p1 = createSprite(40,height/2);
	p1.addImage("default", batImg);
	p1.setCollider("rectangle",0,0,8,32);
	p1.playerNum = 1; 
	p1.scale = 3;

	p2 = createSprite(width-40,height/2);
	p2.addImage("default", batImg); 
	p2.setCollider("rectangle",0,0,8,32);
	p2.targetY = height/2;
	p2.playerNum = 2;
	p2.scale = 3;

	ball = createSprite(width/2,height/2);
	ball.addImage("default", ballImg);
	ball.scale = 3; 
	ball.setCollider("circle",0,0,4);
	ball.spinSpeed = 0;

	p1Score = 0;
	p2Score = 0;
	serveTimer = serveTime;

	startSound.play();
}

function update(){

	//if the serve Timer is > 0, count down and serve
	if (serveTimer > 0){
		serveTimer -= 1/60.0;
		if (serveTimer <= 0){
			serveBall();
			serveTimer = 0;
		}
	}

	//HUMAN PLAYER MOVEMENT
	//we'll make the human player follow the Y coordinate of the mouse
	var differenceBetweenMouseAndP1 = mouseY - p1.position.y;
	p1.velocity.y += differenceBetweenMouseAndP1 * player_accel;

	//if we just set the velocity according to the distance to the mouse, it'll overshoot and go past the mouse
	//so we add some 'damping' - slow it down based on how fast it's going
	p1.velocity.y -= player_damping * p1.velocity.y;
	//set the player movement sound volume according to how fast it's going
	p1moveSound.setVolume(player_one_move_loop_volume*Math.min(Math.abs(p1.velocity.y*0.3),1.0));

	//COMPUTER PLAYER MOVEMENT
	//the idea is that the computer player seeks a target based on the ball's velocity when it crosses
	//the middle line
	if (middleLine.overlap(ball)){ //this only happens when the ball crosses the center line...
		if (ball.velocity.x > 0){ //...and if it's heading to the AI player
			var ballAngle = Math.atan2(ball.velocity.y, ball.velocity.x); //get the angle of the ball's travel
			var predictedYChange = Math.tan(ballAngle)*(width/2-20); //and see how far down it'll go by the time it reaches the goal
			p2.targetY = ball.position.y + predictedYChange;
			
			//the ball can't go higher than 0 or lower than height, so correct the target position
			//the % sign is the 'modulo operator' - it returns the remainder after division
			//for example 5%2=1
			//don't sweat it too much if this seems weird
			if (p2.targetY < 0) {
				p2.targetY  = -(p2.targetY%height);
			}
			else if (p2.targetY >height) {
				p2.targetY  = height - (p2.targetY%height);
			}
		}
	}

	var differenceBetweenTargetAndP2 = p2.targetY - p2.position.y;
	p2.velocity.y += differenceBetweenTargetAndP2 * player_accel * 0.5;
	p2.velocity.y -= player_damping * p2.velocity.y;
	p2moveSound.setVolume(player_two_move_loop_volume*Math.min(Math.abs(p2.velocity.y*0.3),1.0));

	//BALL MOVEMENT CODE
	ball.rotation += ball.spinSpeed;
	ball.spinSpeed *= 0.99; //spin gradually slows down
	spinSound.setVolume(spinning_ball_loop_volume*Math.min(Math.abs(ball.spinSpeed*0.05),1.0));

    //RULE: magnus effect - the ball swerves when it spins.
    ball.velocity.x += 0.0015*(-ball.spinSpeed * ball.velocity.y);
    ball.velocity.y += 0.0015*(ball.spinSpeed * ball.velocity.x);

    //have the ball collide with the player bats
	ball.collide(p1,ballHitPlayer);
	ball.collide(p2,ballHitPlayer);
	ball.collide(walls,ballHitWall); //push ball back into play area if it goes too high or low
	endZones.overlap(ball,ballHitEndZone); //see if ball is touching scoring zones

} //closes "update"


function serveBall(){
	//flip a coin to decide who goes first
	//random() generates a number between 0 and 1. Let's round it to exactly 0 or 1
	var coinflip = Math.round(random());
	if (coinflip == 0){
		ball.velocity.x = serveSpeed; //serve to right player
	}
	else {
		ball.velocity.x = -serveSpeed; //serve to left player
	}
	serveSound.play();
}

//this function is called if the ball hits a player bat
function ballHitPlayer(b,p){ //b will be the ball, p will be the player that got hit
	
	if ((b.velocity.x < 0)&&(p.playerNum==2)){
		return; //player 2 can't hit it if it's going left, so we abort the function with 'return'
	}
	if ((b.velocity.x > 0)&&(p.playerNum==1)){
		return; //player 1 can't hit it if it's going right, so we abort the function with 'return'
	}

	b.velocity.x *= -1.1; //RULE: when hit, reverse the direction of the ball and make it a little faster

	//RULE: the ball gets some vertical velocity from where it touches the bat
	var verticalDistanceFromBallToPlayer = b.position.y - p.position.y;
	b.velocity.y += verticalDistanceFromBallToPlayer*0.1;
	
	b.spinSpeed *= 0.9;//RULE: the ball's spin slows down when it's hit
	//RULE: impart spin to the ball depending on the player's velocity relative to the ball
	b.spinSpeed += 0.6*(b.velocity.y - p.velocity.y); 

	if (p.playerNum == 1){
		p1HitSound.play();
	}
	else {
		p2HitSound.play();
	}

}

//this function is called if the ball hits the invisible walls at the top and bottom
function ballHitWall(b,w){ //w will be the wall hit, b is the ball
	b.spinSpeed *= 0.9; //RULE: hitting the wall slows down the spin
	b.velocity.y *= -1; //bounce back in the opposite direction
	wallSound.play();
}

//this function is called if the ball hits the invisible zones behind the players
function ballHitEndZone(z,b){ //z will be the zone that was hit, b is the ball
	console.log("point scored for player " + z.playerNum);
	if (z.playerNum == 1) { //player 1 scored
		p1Score += 1;
		p1ScoreSound.play();
	}
	else if (z.playerNum == 2) { //player 2 scored
		p2Score += 1;
		p2ScoreSound.play();
	}
	//reset if the score gets to 10
	if ((p1Score > 9)||(p2Score > 9)){
		endSound.play();
		resetGame();
	}

	//after a goal, move the players and ball back to the starting positions
	p1.position.y = height/2;
	p1.velocity.y = 0;
	p2.position.y = height/2;
	p2.velocity.y = 0;
	p2.targetY = height/2;

	b.position.x = width/2;
	b.position.y = height/2;
	b.velocity.x = 0;
	b.velocity.y = 0;
	b.rotation = 0;
	b.spinSpeed = 0;

	serveTimer = serveTime;
}

//The draw() function is called once a frame to draw all the things in the game.
//The order we draw them matters - newer things are drawn on top of older things
//So we start with the background
function draw() {
	
	//the background() function fills the background with a color.
	//in this case I'm giving it a non-opaque alpha, so that the buffer
	//isn't totally cleared each time - this generates a nice motion blur
	background(0, 0, 0,80);	

	//time to draw the player scores. We want them in the background, so draw it first
	fill(80, 80, 80);	//change the color of the text to dark grey, we don't want it interfering
	text(p1Score + " : " + p2Score,width/2, 50);
	
	//here we call our custom update function to process input and movement
	update(); 
	
	//note we don't need to draw the walls - they're offscreen

	//draw the player sprites and the ball
	drawSprite(p1);
	drawSprite(p2);
	drawSprite(ball);

}


